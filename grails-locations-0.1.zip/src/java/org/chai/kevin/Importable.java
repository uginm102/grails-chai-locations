package org.chai.kevin;

public interface Importable {
	
	public Object fromExportString(Object value);
	
}
