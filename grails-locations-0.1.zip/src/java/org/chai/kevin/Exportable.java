package org.chai.kevin;

public interface Exportable {
	
	public String toExportString();
	
}
